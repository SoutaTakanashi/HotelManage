
public class FamilyRoom extends Room{
	
	public FamilyRoom(String w,int num,String sta,int id){
		super(w,num,sta,id);
		setCapacity(4);
		setCleaningDuration(120);
	}
}
